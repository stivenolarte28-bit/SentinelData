# SentinelData

## Descripción del proyecto

SentinelData es una API desarrollada con Node.js y Express orientada a la gestión segura de usuarios y registros de información. El sistema utiliza MongoDB Atlas para la persistencia de los datos y cuenta con una estructura modular que separa la configuración, los modelos, los controladores y las rutas.

Actualmente, SentinelData integra un módulo de autenticación de usuarios y un módulo de gestión de registros mediante operaciones CRUD.

## Tecnologías utilizadas

- Node.js
- Express.js
- MongoDB Atlas
- Mongoose
- bcrypt
- dotenv
- Jest
- Supertest

## Módulos implementados

### 1. Autenticación

Permite realizar el registro e inicio de sesión de usuarios, incorporando mecanismos de protección de contraseñas mediante bcrypt.

### 2. Gestión de registros

Permite realizar las siguientes operaciones:

- Crear registros.
- Consultar todos los registros.
- Consultar un registro por ID.
- Actualizar registros.
- Eliminar registros.
## Arquitectura del proyecto

SentinelData utiliza una arquitectura modular por capas que permite separar las responsabilidades del sistema y facilita su mantenimiento, escalabilidad y realización de pruebas.

La aplicación se organiza en las siguientes capas:

- **Configuración:** administra la conexión con MongoDB Atlas.
- **Modelos:** define la estructura y validación de los datos mediante Mongoose.
- **Controladores:** contiene la lógica de negocio de cada módulo.
- **Rutas:** define los endpoints disponibles en la API.
- **Pruebas:** verifica automáticamente el funcionamiento de los módulos mediante Jest y Supertest.

## Estructura del proyecto

SentinelData/
├── src/
│ ├── config/
│   │   └── Database.js
│   ├── controllers/
│   │   ├── auth.controller.js
│   │   └── registro.controller.js
│   ├── models/
│   │   ├── Usuario.js
│   │   └── Registro.js
│   ├── routes/
│   │   ├── auth.routes.js
│   │   └── registro.routes.js
│   ├── app.js
│   └── server.js
├── test/
│   ├── Auth.test.js
│   └── Registro.test.js
├── .env.example
├── .gitignore
├── ENDPOINTS.text
├── package.json
└── README.md
## Instalación y configuración

### Requisitos previos

Para ejecutar SentinelData se requiere:

- Node.js
- npm
- Una base de datos en MongoDB Atlas
- Editor de código, como Acode o Visual Studio Code

### Instalación

1. Ubicarse en la carpeta principal del proyecto.
2. Instalar las dependencias mediante:

npm install

3. Crear un archivo `.env` en la raíz del proyecto tomando como referencia `.env.example`.

### Variables de entorno

SentinelData utiliza variables de entorno para proteger información sensible de configuración.

Ejemplo:

MONGODB_URI=tu_cadena_de_conexion
PORT=3000

El archivo `.env` no debe publicarse ni incluirse en el repositorio, ya que puede contener credenciales de acceso a la base de datos.

### Ejecución

Para iniciar SentinelData:

node src/server.js

El servidor utiliza el puerto configurado en las variables de entorno.

### Pruebas automatizadas

Para ejecutar las pruebas:

npm test

Actualmente, SentinelData cuenta con dos suites de pruebas:

- Pruebas del módulo de autenticación.
- Pruebas del módulo de registros.

Resultado verificado:

- Test Suites: 2 passed, 2 total.
- Tests: 10 passed, 10 total.
- Pruebas fallidas: 0.
## Seguridad y buenas prácticas

SentinelData incorpora diferentes mecanismos y prácticas orientadas a mejorar la seguridad, organización y mantenimiento del código.

### Protección de contraseñas

Las contraseñas de los usuarios se protegen mediante bcrypt, evitando almacenar contraseñas en texto plano dentro de la base de datos.

### Variables de entorno

La información sensible, como la cadena de conexión a MongoDB Atlas, se administra mediante variables de entorno utilizando dotenv.

El archivo `.env` se mantiene fuera del control de versiones mediante `.gitignore`, evitando la exposición accidental de credenciales.

### Validación de datos

Los modelos definidos con Mongoose establecen campos obligatorios y reglas de validación antes de almacenar la información en MongoDB.

### Manejo de errores

Los controladores implementan bloques `try/catch` y códigos de estado HTTP para responder correctamente ante errores de validación, registros inexistentes o fallos internos.

### Separación de responsabilidades

El proyecto utiliza una estructura modular que separa:

- Configuración de base de datos.
- Modelos.
- Controladores.
- Rutas.
- Pruebas automatizadas.

Esta organización facilita el mantenimiento, las pruebas y la ampliación futura de SentinelData.
## Endpoints de la API

### Autenticación

#### Registrar usuario
- Método: POST
- Ruta: /api/auth/registro

#### Iniciar sesión
- Método: POST
- Ruta: /api/auth/login

### Gestión de registros

#### Crear registro
- Método: POST
- Ruta: /api/registros

#### Consultar todos los registros
- Método: GET
- Ruta: /api/registros

#### Consultar registro por ID
- Método: GET
- Ruta: /api/registros/:id

#### Actualizar registro
- Método: PUT
- Ruta: /api/registros/:id

#### Eliminar registro
- Método: DELETE
- Ruta: /api/registros/:id
