const request = require("supertest");
const mongoose = require("mongoose");
require("dotenv").config();

const app = require("../src/app");
const Registro = require("../src/models/Registro");


describe("Pruebas del módulo de registros - SentinelData", () => {

  let registroId;

  beforeAll(async () => {
  if (mongoose.connection.readyState !== 1) {
    await mongoose.connect(process.env.MONGODB_URI);
  }

  await Registro.deleteMany({
    titulo: "Registro de prueba SentinelData"
  });
}, 15000);


afterAll(async () => {
  await Registro.deleteMany({
    titulo: "Registro de prueba SentinelData"
  });

  if (mongoose.connection.readyState !== 0) {
    await mongoose.connection.close();
  }
}, 15000);

  test("Debe crear un registro correctamente", async () => {
    const respuesta = await request(app)
      .post("/api/registros")
      .send({
  titulo: "Registro de prueba SentinelData",
  descripcion: "Registro creado para pruebas automatizadas",
  categoria: "Prueba",
  estado: "activo"
});

    expect(respuesta.statusCode).toBe(201);
    expect(respuesta.body.registro).toBeDefined();

    registroId = respuesta.body.registro._id;
  });

  test("Debe consultar todos los registros", async () => {
    const respuesta = await request(app)
      .get("/api/registros");

    expect(respuesta.statusCode).toBe(200);
    expect(Array.isArray(respuesta.body)).toBe(true);
  });

  test("Debe consultar un registro por ID", async () => {
    const respuesta = await request(app)
      .get(`/api/registros/${registroId}`);

    expect(respuesta.statusCode).toBe(200);
    expect(respuesta.body._id).toBe(registroId);
  });

  test("Debe actualizar un registro correctamente", async () => {
    const respuesta = await request(app)
      .put(`/api/registros/${registroId}`)
      .send({
        descripcion: "Registro actualizado mediante prueba automatizada"
      });

    expect(respuesta.statusCode).toBe(200);
    expect(respuesta.body.registro.descripcion)
      .toBe("Registro actualizado mediante prueba automatizada");
  });

  test("Debe eliminar un registro correctamente", async () => {
    const respuesta = await request(app)
      .delete(`/api/registros/${registroId}`);

    expect(respuesta.statusCode).toBe(200);
    expect(respuesta.body.mensaje)
      .toBe("Registro eliminado correctamente");
  });

});
