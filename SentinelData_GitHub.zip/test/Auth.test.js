const request = require("supertest");
const mongoose = require("mongoose");
require("dotenv").config();

const app = require("../src/app");
const conectarBaseDatos = require("../src/config/Database");
const Usuario = require("../src/models/Usuario");

beforeAll(async () => {
  await conectarBaseDatos();
});

afterAll(async () => {
  await mongoose.connection.close();
});

describe("Pruebas de autenticación - SentinelData", () => {

  const usuarioPrueba = {
    usuario: "usuario_test_automatizado",
    password: "ClaveTest123"
  };

  beforeAll(async () => {
    await Usuario.deleteOne({
      usuario: usuarioPrueba.usuario
    });
  });

  afterAll(async () => {
    await Usuario.deleteOne({
      usuario: usuarioPrueba.usuario
    });
  });

  test("Debe registrar un usuario correctamente", async () => {
    const respuesta = await request(app)
      .post("/api/auth/registro")
      .send(usuarioPrueba);

    expect(respuesta.statusCode).toBe(201);
    expect(respuesta.body.mensaje).toBe(
      "Usuario registrado correctamente"
    );
  });

  test("Debe iniciar sesión correctamente", async () => {
    const respuesta = await request(app)
      .post("/api/auth/login")
      .send(usuarioPrueba);

    expect(respuesta.statusCode).toBe(200);
    expect(respuesta.body.acceso).toBe(true);
  });

  test("Debe rechazar una contraseña incorrecta", async () => {
    const respuesta = await request(app)
      .post("/api/auth/login")
      .send({
        usuario: usuarioPrueba.usuario,
        password: "Incorrecta123"
      });

    expect(respuesta.statusCode).toBe(401);
  });

  test("Debe rechazar campos vacíos", async () => {
    const respuesta = await request(app)
      .post("/api/auth/login")
      .send({});

    expect(respuesta.statusCode).toBe(400);
  });

  test("Debe impedir registrar un usuario duplicado", async () => {
    const respuesta = await request(app)
      .post("/api/auth/registro")
      .send(usuarioPrueba);

    expect(respuesta.statusCode).toBe(400);
  });

});
