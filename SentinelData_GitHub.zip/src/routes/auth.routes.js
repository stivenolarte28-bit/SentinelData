// ==========================================
// SentinelData - Rutas de autenticaciòn
// Autor: Anderson Stiven Olarte Junco
// ==========================================

// Importamos express
const express = require("express");

//Creamos el enrutador de Express
const router = express.Router();

// Importamos las funciones del controlador
const {
  registrar,
  login
} = require("../controllers/auth.controller");

//Ruta para registrar un nuevo usuario
router.post("/registro", registrar);

//Ruta para iniciar sesiòn
router.post("/login", login);

// Exportamos las rutas
module.exports = router;