const express = require("express");
const router = express.Router();

const {
  crearRegistro,
  obtenerRegistros,
  obtenerRegistroPorId,
  actualizarRegistro,
  eliminarRegistro
} = require("../controllers/registro.controller");

// Crear un registro
router.post("/", crearRegistro);

// Consultar todos los registros
router.get("/", obtenerRegistros);

// Consultar un registro por ID
router.get("/:id", obtenerRegistroPorId);

// Actualizar un registro
router.put("/:id", actualizarRegistro);

//Eliminar un registro
router.delete("/:id", eliminarRegistro);

module.exports = router;
