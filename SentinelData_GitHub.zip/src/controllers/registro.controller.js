const Registro = require("../models/Registro");

// Crear un nuevo registro
const crearRegistro = async (req, res) => {
  try {
    
    const { titulo, descripcion, categoria, estado } = req.body;

    if (!titulo || !descripcion || !categoria) {
      return res.status(400).json({
        mensaje: "Título, descripción y categoría son obligatorios"
      });
    }

    const nuevoRegistro = new Registro({
  titulo: req.body.titulo,
  descripcion: req.body.descripcion,
  categoria: req.body.categoria,
  estado: req.body.estado
});

    await nuevoRegistro.save();

    res.status(201).json({
      mensaje: "Registro creado correctamente",
      registro: nuevoRegistro
    });
  } catch (error) {
  console.error("ERROR AL CREAR REGISTRO:", error);

  res.status(500).json({
    mensaje: "Error al crear el registro"
  });
}

};

// Consultar todos los registros
const obtenerRegistros = async (req, res) => {
  try {
    const registros = await Registro.find();

    res.status(200).json(registros);
  } catch (error) {
    res.status(500).json({
      mensaje: "Error al consultar los registros"
    });
  }
};

// Consultar un registro por ID
const obtenerRegistroPorId = async (req, res) => {
  try {
    const registro = await Registro.findById(req.params.id);

    if (!registro) {
      return res.status(404).json({
        mensaje: "Registro no encontrado"
      });
    }

    res.status(200).json(registro);
  } catch (error) {
    res.status(400).json({
      mensaje: "ID de registro no válido"
    });
  }
};

// Actualizar un registro
const actualizarRegistro = async (req, res) => {
  try {
    const registro = await Registro.findByIdAndUpdate(
      req.params.id,
      req.body,
      {
        new: true,
        runValidators: true
      }
    );

    if (!registro) {
      return res.status(404).json({
        mensaje: "Registro no encontrado"
      });
    }

    res.status(200).json({
      mensaje: "Registro actualizado correctamente",
      registro
    });
  } catch (error) {
    res.status(400).json({
      mensaje: "No fue posible actualizar el registro"
    });
  }
};

// Eliminar un registro
const eliminarRegistro = async (req, res) => {
  try {
    const registro = await Registro.findByIdAndDelete(req.params.id);

    if (!registro) {
      return res.status(404).json({
        mensaje: "Registro no encontrado"
      });
    }

    res.status(200).json({
      mensaje: "Registro eliminado correctamente"
    });
  } catch (error) {
    res.status(400).json({
      mensaje: "No fue posible eliminar el registro"
    });
  }
};

module.exports = {
  crearRegistro,
  obtenerRegistros,
  obtenerRegistroPorId,
  actualizarRegistro,
  eliminarRegistro
};
