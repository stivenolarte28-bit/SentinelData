// ==========================================
// SentinelData - Controlador de autenticacion
// ==========================================

const bcrypt = require("bcrypt");
const Usuario = require("../models/Usuario");

// Registrar un nuevo usuario
const registrar = async (req, res) => {
  try {
    const { usuario, password } = req.body;

    // Validamos los campos
    if (!usuario || !password) {
      return res.status(400).json({
        mensaje: "Debe ingresar usuario y contraseña"
      });
    }

    // Verificamos si el usuario ya existe en MongoDB
    const usuarioExistente = await Usuario.findOne({ usuario });

    if (usuarioExistente) {
      return res.status(400).json({
        mensaje: "El usuario ya se encuentra registrado"
      });
    }

    // Ciframos la contraseña
    const passwordCifrada = await bcrypt.hash(password, 10);

    // Creamos el usuario en MongoDB
    const nuevoUsuario = new Usuario({
      usuario,
      contrasena: passwordCifrada
    });

    await nuevoUsuario.save();

    return res.status(201).json({
      mensaje: "Usuario registrado correctamente"
    });

  } catch (error) {
    console.error("Error al registrar usuario:", error);

    return res.status(500).json({
      mensaje: "Error interno del servidor"
    });
  }
};

// Iniciar sesion
const login = async (req, res) => {
  try {
    const { usuario, password } = req.body;

    // Validamos los campos
    if (!usuario || !password) {
      return res.status(400).json({
        mensaje: "Debe ingresar usuario y contraseña"
      });
    }

    // Buscamos al usuario en MongoDB
    const usuarioEncontrado = await Usuario.findOne({ usuario });

    if (!usuarioEncontrado) {
      return res.status(401).json({
        mensaje: "Usuario o contraseña incorrectos"
      });
    }

    // Comparamos la contraseña con el hash almacenado
    const passwordCorrecta = await bcrypt.compare(
      password,
      usuarioEncontrado.contrasena
    );

    if (!passwordCorrecta) {
      return res.status(401).json({
        mensaje: "Usuario o contraseña incorrectos"
      });
    }

    return res.status(200).json({
      mensaje: "Autenticación satisfactoria",
      acceso: true
    });

  } catch (error) {
    console.error("Error al iniciar sesión:", error);

    return res.status(500).json({
      mensaje: "Error interno del servidor"
    });
  }
};

module.exports = {
  registrar,
  login
};
