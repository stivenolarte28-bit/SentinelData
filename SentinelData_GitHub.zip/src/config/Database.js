const mongoose = require("mongoose");

async function conectarBaseDatos() {
  try{
    await mongoose.connect(process.env.MONGODB_URI);
    console.log("Base de datos conectada correctamente");
  } catch (error) {
    console.error("Error al conectacr con la base de datos:",error.message);
    throw error;
  }
}

module.exports = conectarBaseDatos;