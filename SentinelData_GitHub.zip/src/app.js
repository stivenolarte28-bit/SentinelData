// ==========================================
// SENTINELDATA - API REST DE AUTENTICACIÓN
// Autor: Anderson Stiven Olarte Junco
// ==========================================

// Importamos Express
const express = require("express");

// Cargamos las variables de entorno
require("dotenv").config();

//Importamos la conexiòn a MongoDB
const conectarBaseDatos = require("./config/Database");

// Creamos la aplicación
const app = express();

// Permitimos recibir información en formato JSON
app.use(express.json());

// Importamos las rutas de autenticación
const authRoutes = require("./routes/auth.routes");
const registroRoutes = require("./routes/registro.routes");

// Conectamos las rutas con la aplicación
app.use("/api/auth", authRoutes);
app.use("/api/registros", registroRoutes);

// Ruta principal para comprobar el funcionamiento
app.get("/", (req, res) => {
    res.json({
        aplicacion: "SentinelData",
        mensaje: "API de autenticación funcionando correctamente"
    });
});

module.exports = app;
