require("dotenv").config();

const app = require("./app");
const conectarBaseDatos = require("./config/Database");

const PORT = process.env.PORT || 3000;

async function iniciarServidor() {
  try {
    await conectarBaseDatos();

    app.listen(PORT, () => {
      console.log(
        `Servidor SentinelData ejecutándose en el puerto ${PORT}`
      );
    });
  } catch (error) {
    console.error("No fue posible iniciar SentinelData");
    process.exit(1);
  }
}

iniciarServidor();
